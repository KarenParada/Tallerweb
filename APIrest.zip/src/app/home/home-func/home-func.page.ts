import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-func',
  templateUrl: './home-func.page.html',
  styleUrls: ['./home-func.page.scss'],
})
export class HomeFuncPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
