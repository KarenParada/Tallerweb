import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AlertController, ModalController } from '@ionic/angular';
import { ListModalComponent } from 'src/app/list-modal/list-modal.component';

interface Grupo {
  id: string;
  Nombre: string;
  tipoTurnoInicial: string;
}

@Component({
  selector: 'app-home-jefe-gestionturnos',
  templateUrl: './home-jefe-gestionturnos.page.html',
  styleUrls: ['./home-jefe-gestionturnos.page.scss']
})

export class HomeJefeGestionturnosPage {
  today = new Date();
  isDayTime = this.today.getHours() > 8 && this.today.getHours() < 20;
  unreadNotifications = 0; 
  selectedTab = 'gestionturnos';
  fecha = new Date().toISOString();
  horizonteDias: number;
  fotoUrl: string;
  profesionales: any[] = [];
  tiposTurno: any[] = [];
  gruposTurno: Grupo[] = [];

  constructor(private router: Router, private afs: AngularFirestore, private afAuth: AngularFireAuth, private alertController: AlertController, private modalController: ModalController) { }

  ngOnInit() {
    this.afAuth.authState.subscribe(user => {
      if (user) {
        this.afs.collection('profesionales').doc(user.uid).valueChanges().subscribe((user: any) => {
          this.fotoUrl = user.foto;
        });
      }
    });
    
    this.afs.collection('profesionales').snapshotChanges().subscribe((snapshots: any[]) => {
      this.profesionales = snapshots.map(snapshot => {
        const data = snapshot.payload.doc.data();
        const id = snapshot.payload.doc.id;
        return { id, ...data };
      });
    });
    

    this.afs.collection('TipoTurno').valueChanges().subscribe(data => {
      this.tiposTurno = data;
    });

    this.afs.collection('Grupoturno').snapshotChanges().subscribe((snapshots: any[]) => {
      this.gruposTurno = snapshots.map(snapshot => {
        const data = snapshot.payload.doc.data() as Grupo;
        const id = snapshot.payload.doc.id;
        return { ...data, id: data.id ? data.id : id };
      });
      this.gruposTurno = this.gruposTurno.filter((grupo: Grupo) => grupo.Nombre !== 'Sin definir');
      this.gruposTurno.sort((a, b) => a.Nombre.localeCompare(b.Nombre));
    });
  }

  programarTurnos() {
    console.log('Fecha:', this.fecha);
    console.log('Horizonte de días:', this.horizonteDias);
    for (let i = 0; i < this.horizonteDias; i++) {
      const fechaTurno = new Date(this.fecha);
      fechaTurno.setDate(fechaTurno.getDate() + i);
      console.log('Fecha',fechaTurno)
      for (const profesional of this.profesionales) {
        if (profesional.rol === 'funcionario' && profesional.Activo === true) {
          console.log('cumple condición: ',profesional.nombre)
          const grupo = this.gruposTurno.find(g => g.id === profesional.grupoturno);
          console.log('Grupo desde profesional: ',profesional.grupoturno)
          console.log('Grupo profesional: ',grupo)
          if (grupo) {
            const tipoTurno = this.getTipoTurno(grupo, i);
            console.log('Tipo turno asignado:',tipoTurno)
            this.afs.collection('turnos').add({
              fecha: fechaTurno.toISOString(),
              tipoTurno: tipoTurno,
              profesionalId: profesional.id,
              realizado: false
            }).then(() => {
              console.log('Datos añadidos correctamente a Firebase');
            }).catch((error) => {
              console.error('Error añadiendo datos a Firebase:', error);
            });
          }
        }
      }
    }
  }

  getTipoTurno(grupo: Grupo, dia: number) {
    console.log('grupo tipoturno inicial: ',grupo.tipoTurnoInicial)
    console.log('index of: ',this.tiposTurno.indexOf(grupo.tipoTurnoInicial)) 
    console.log('largo tiposturno',this.tiposTurno.length)
    let nombresTiposTurno = this.tiposTurno.map(tipoTurno => tipoTurno.Nombre);
    const indiceTipoTurno = (dia + nombresTiposTurno.indexOf(grupo.tipoTurnoInicial)) % nombresTiposTurno.length;
    const tipoTurno = this.tiposTurno[indiceTipoTurno];
    console.log('Tipo de turno para el grupo', grupo.Nombre, 'en el día', dia, ':', tipoTurno.Nombre);
    return tipoTurno.Nombre;
  }

  navigateToPage(pageName: string) {
    this.router.navigate([`/${pageName}`]);
  }

  segmentChanged(ev: any) {
    this.selectedTab = ev.detail.value;
    this.navigateToPage(`/home-jefe-${this.selectedTab}`);
  }
}
