import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HomeJefeCalendarioPageRoutingModule } from './home-jefe-calendario-routing.module';

import { HomeJefeCalendarioPage } from './home-jefe-calendario.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HomeJefeCalendarioPageRoutingModule
  ],
  declarations: [HomeJefeCalendarioPage]
})
export class HomeJefeCalendarioPageModule {}
