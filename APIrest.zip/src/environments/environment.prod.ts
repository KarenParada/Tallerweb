export const environment = {
  production: true,
     firebaseConfig : {
    apiKey: "",
    authDomain: "auth-test-7b9fb.firebaseapp.com",
    projectId: "auth-test-7b9fb",
    storageBucket: "auth-test-7b9fb.appspot.com",
    messagingSenderId: "909454782709",
    appId: "1:909454782709:web:70ca68de07cf04e84fd5bc",
    measurementId: "G-8TMKGEFEKD"
  }
};
